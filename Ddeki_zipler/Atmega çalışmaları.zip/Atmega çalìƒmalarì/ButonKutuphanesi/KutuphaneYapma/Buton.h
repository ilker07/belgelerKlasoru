#ifndef Buton
#define Buton

#include <avr/io.h>

bool butonKontrol(unsigned char butonPin,unsigned char portBit,int sure);

bool birinci=true;
bool beklendi=true;
int basma_suresi,birakma_suresi;

bool butonKontrol(unsigned char butonPin,unsigned char portBit,int sure)
{


    if(bit_is_set(butonPin,portBit))
    {
        basma_suresi++;
        birakma_suresi=0;
        if(basma_suresi>sure)
        {
           if(beklendi)
           {
               if(birinci==true && beklendi==true)
               {
                     
               beklendi=false;
               birinci=false;
               return 1;
               }
               else if(birinci==false && beklendi==true)
               {
                 
                 birinci=true;
                 return 0;
               }
              
               

           }
          
        basma_suresi=0;
     
        }
       
    }

    else
    {

        birakma_suresi++;
        basma_suresi=0;
        if(birakma_suresi>sure)
        {
          
         
            beklendi=true;   
            birakma_suresi=0;

           

         
        }
      
    }
    
    

}








#endif 
