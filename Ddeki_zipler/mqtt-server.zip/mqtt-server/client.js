///Sayıyı okuma 

var fs = require('fs');
var sayi;
try {  
  var  data = fs.readFileSync('sayi.txt', 'utf8');  
  sayi =parseInt(data);
} catch(e) {
    console.log('Error:', e.stack);
}



///MQTT SERVER 
var mqtt = require('mqtt');
var client = mqtt.connect('mqtt://167.99.254.82:1883');//127.0.0.1

client.subscribe('led');

client.on('connect', function() {
	console.log('connected!');

    client.subscribe('new-user',function(err)
    {
        if(!err)
        {
            client.publish('new-user','Kisi'+sayi);
            sayi++;
            if(sayi>1000)
              sayi=0;
            fs.writeFile('sayi.txt', sayi.toString(), err => {
                if (err) {
                  console.error(err)
                  return
                }
               
              })
        }
    })
});

client.on('message',function(topic,message){
console.log(topic,':',message.toString());
});