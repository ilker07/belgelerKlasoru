
var fs = require('fs');



////Server
var mosca = require('mosca');

var settings = {
	port: 1883,
	http: {
		port: 3000,
	},
};

var server = new mosca.Server(settings);

server.on('clientConnected', function(client) {
	console.log('client connected', client.id);
});

server.on('clientDisconnected', function(client) {
	console.log('client disconnected -', client.id);
	
	var sayi;
	try {  
		var  data = fs.readFileSync('sayi.txt', 'utf8');  
		sayi =parseInt(data);
	  } catch(e) {
		  console.log('Error:', e.stack);
	  }
	  sayi--;
	  fs.writeFile('sayi.txt', sayi.toString(), err => {
		if (err) {
		  console.error(err)
		  return
		}
	   
	  })

});

// fired when a message is received
server.on('published', function(packet, client) {
	console.log('Published', packet.payload.toString());
	

});

server.on('ready', setup);

// fired when the mqtt server is ready
function setup() {
	console.log('Mosca server is up and running');
}

/*
server.close(function(){
	console.log('Mosca server stopped!!');
})*/

