const fs = require('fs')

var sayi=5;
var deger=sayi.toString();

fs.writeFile('sayi.txt', deger, err => {
  if (err) {
    console.error(err)
    return
  }
 
})