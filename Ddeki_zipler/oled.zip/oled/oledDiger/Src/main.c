
#include "main.h"
#include "spi.h"
#include "gpio.h"


#include "st7789.h"



void SystemClock_Config(void);

int main(void)
{
  
  HAL_Init();

 
  SystemClock_Config();

 
  MX_GPIO_Init();
  MX_SPI1_Init();
  HAL_GPIO_WritePin(BLK_GPIO_Port, BLK_Pin, GPIO_PIN_SET);
  
  while (1)
  {
    ST7789_Init(240, 240);
	 
    ST7789_FillScreen(BLACK);
    ST7789_SetBL(100);
		
//    uint16_t color = RGB565(255, 0, 0);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);
//  
//    color = RGB565(0, 255, 0);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(50, 55, 50);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(0, 0, 255);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(255, 255, 0);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(255, 0, 255);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(0, 255, 255);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);

//    color = RGB565(255, 255, 255);
//    ST7789_FillScreen(color);
//    HAL_Delay(500);
//		
//    ST7789_FillScreen(BLACK);
//    ST7789_SetBL(100);

    ST7789_FillScreen(BLACK);
    ST7789_SetBL(100);
		ST7789_DrawChar_5x8(100, 100, RGB565(0, 255, 255), RGB565(0, 0, 0), 0, 'A');
		ST7789_DrawChar_7x11(60, 60, RGB565(0, 255, 255), RGB565(0, 0, 0), 0, 0xBB);

    ST7789_print_5x8(10, 30, RGB565(0, 255, 255), RGB565(0, 0, 0), 0, "Привет"); 		
    ST7789_print_7x11(40, 40, RGB565(0, 255, 255), RGB565(0, 0, 0), 0, "Welcome"); 		

    HAL_Delay(10000);

//		for (uint8_t y = 0; y<240 ; y++) {
//			ST7789_DrawLine(120, 120, 239, y, RGB565(y+10, 0, 0));
//		}
//   		
//		for (uint8_t x = 0; x<240 ; x++) {
//			ST7789_DrawLine(120, 120, x, 239, RGB565(0, x+10, 0));
//		}
//   
//		for (uint8_t y = 0; y<240 ; y++) {
//			ST7789_DrawLine(120, 120, 0, y, RGB565(0, 0, y+10));
//		}
// 
//		for (uint8_t x = 0; x<240 ; x++) {
//			ST7789_DrawLine(120, 120, x, 0, RGB565(x+10, x+10, x+10));
//		}
//    HAL_Delay(1000);

//    ST7789_FillScreen(BLACK);
//    ST7789_SetBL(100);

//    for (uint8_t x = 0; x < 240 ; x = x + 20) {
//			for (uint8_t y = 0; y < 240; y = y + 20) {
//				ST7789_DrawRectangleFilled(x + 3, y + 3, x + 17, y + 17, RGB565(x, y, 0));
//				ST7789_DrawRectangle(x + 2, y + 2, x + 19, y + 19, RGB565(250, 250, 250));
//			}
//		}
//    HAL_Delay(1000);

//    ST7789_FillScreen(BLACK);
//    ST7789_SetBL(100);

//    for (uint8_t x = 0; x < 240 ; x = x + 20) {
//			for (uint8_t y = 0; y < 240; y = y + 20) {
//        ST7789_DrawCircleFilled(x + 10, y + 10, 8, RGB565(x, y, 0));
//        ST7789_DrawCircle(x + 10, y + 10, 9, RGB565(0, y, x));
//			}
//		}
//    HAL_Delay(1000);

//    ST7789_FillScreen(BLACK);
 //   ST7789_SetBL(100);
	
  }
}


void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  
}



