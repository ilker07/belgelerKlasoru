#ifndef HABER_H
#define HABER_H

#include <Arduino.h>

//#define USART_BAUDRATE 9600
#define UBRR_VALUE 8 //(((F_CPU / (USART_BAUDRATE * 16UL))) - 1)

void usartBasla(void);
void usartGonder(String veri);
char usartAl(void);
boolean usartBul(String veri); 
void charGonder(char  veri);





#endif
