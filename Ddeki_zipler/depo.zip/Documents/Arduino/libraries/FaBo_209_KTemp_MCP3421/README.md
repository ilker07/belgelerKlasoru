# FaBoKTemp-MCP3421-Library

This is a library for FaBo #209 KTemp I2C Brick.

## FaBo KTemp I2C Brick

[#209 KTemp I2C Brick](http://fabo.io/209.html)

## MCP3421

MCP3421 is 18-Bit Analog-to-Digital Converter.

### MCP3421 Datasheet

[MCP3421 Datasheet](http://ww1.microchip.com/downloads/jp/DeviceDoc/22003E_JP.pdf)

## Releases

- 1.0.0 Initial release.

## How to install

[Installing Additional Arduino Libraries](https://www.arduino.cc/en/Guide/Libraries)
