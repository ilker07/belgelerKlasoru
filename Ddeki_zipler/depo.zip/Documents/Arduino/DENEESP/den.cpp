#include "den.h"
#include <util/delay.h>
#include <Arduino.h>

void uartBasla(void)
{
UBRR0H=(uint8_t)(UBRR_VALUE>>8);
UBRR0L=(uint8_t)UBRR_VALUE;
UCSR0C |= (1<<UCSZ01)|(1<<UCSZ00);//8 bit veri için
UCSR0B |= (1<<RXEN0)|(1<<TXEN0);
}

void uartGonder(char *u8Data)
{

  uint16_t i=0;
  while(u8Data[i] !='\0')
  {
    
    while(!(UCSR0A&(1<<UDRE0))){}
    UDR0 = u8Data[i] ;
    i++;
    
  }


}
