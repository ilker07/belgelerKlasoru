#ifndef DEN_H
#define DEN_H

#include <Arduino.h>


//#define USART_BAUDRATE 9600
#define UBRR_VALUE 8 //(((F_CPU / (USART_BAUDRATE * 16UL))) - 1)normal 8  x2 icin=> 16

void uartBasla(void);
void uartGonder(char *u8Data);





#endif
