#ifndef ESP8266_H
#define ESP8266_H

#include <Arduino.h>


//#define USART_BAUDRATE 115200
#define UBRR_VALUE 8 //(((F_CPU / (USART_BAUDRATE * 16UL))) - 1) x2 icin=> 16

void uartBasla(void);
void uartGonder(char *u8Data);
void usartGonder(String veri);
void kurulum(String deger,int sure);





#endif
