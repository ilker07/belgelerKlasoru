

    
    
    var metin="MustafaAYKUT ilker ay";
    
    document.getElementById('sonuc').innerHTML=metin.search(/ilker/);

    document.getElementById('sonuc2').innerHTML=metin.search(/aykut/i);//Büyük harf küçük harf önemli değil.

    document.getElementById('sonuc3').innerHTML=/ilker/.exec(metin);//metinde bu kelime var mı?
   
   
