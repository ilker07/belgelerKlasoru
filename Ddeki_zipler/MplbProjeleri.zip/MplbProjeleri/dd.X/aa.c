


#include <xc.h>
#include <stdio.h>
#define _XTAL_FREQ 8000000

#pragma config RETEN = OFF      // VREG Sleep Enable bit (Disabled - Controlled by SRETEN bit)
#pragma config INTOSCSEL = LOW  // LF-INTOSC Low-power Enable bit (LF-INTOSC in Low-power mode during Sleep)
#pragma config SOSCSEL = LOW    // SOSC Power Selection and mode Configuration bits (Low Power SOSC circuit selected)
#pragma config XINST = OFF      // Extended Instruction Set (Enabled)

#pragma config FOSC = INTIO2        // RCIO  HS2
#pragma config PLLCFG = OFF     // PLL x4 Enable bit (Disabled)
#pragma config FCMEN = OFF      // Fail-Safe Clock Monitor (Disabled)
#pragma config IESO = OFF       // Internal External Oscillator Switch Over Mode (Disabled)

// CONFIG2L
#pragma config PWRTEN = OFF     // Power Up Timer (Disabled)
#pragma config BOREN = OFF  // Brown Out Detect (Enabled in hardware, SBOREN disabled)
#pragma config BORV = 3         // Brown-out Reset Voltage bits (1.8V)
#pragma config BORPWR = ZPBORMV // BORMV Power level (ZPBORMV instead of BORMV is selected)

// CONFIG2H
#pragma config WDTEN = OFF  // Watchdog Timer (WDT enabled in hardware; SWDTEN bit disabled)
#pragma config WDTPS = 1048576  // Watchdog Postscaler (1:1048576)

// CONFIG3L
#pragma config RTCOSC = SOSCREF // RTCC Clock Select (RTCC uses SOSC)

// CONFIG3H
#pragma config CCP2MX = PORTC   // CCP2 Mux (RC1)
#pragma config MSSPMSK = MSK7   // MSSP address masking (7 Bit address masking mode)
#pragma config MCLRE = ON       // Master Clear Enable (MCLR Enabled, RG5 Disabled)

// CONFIG4L
#pragma config STVREN = OFF      // Stack Overflow Reset (Enabled)
#pragma config BBSIZ = BB2K     // Boot Block Size (2K word Boot Block size)

// CONFIG5L
#pragma config CP0 = OFF        // Code Protect 00800-03FFF (Disabled)
#pragma config CP1 = OFF        // Code Protect 04000-07FFF (Disabled)
#pragma config CP2 = OFF        // Code Protect 08000-0BFFF (Disabled)
#pragma config CP3 = OFF        // Code Protect 0C000-0FFFF (Disabled)
#pragma config CP4 = OFF        // Code Protect 10000-13FFF (Disabled)
#pragma config CP5 = OFF        // Code Protect 14000-17FFF (Disabled)
#pragma config CP6 = OFF        // Code Protect 18000-1BFFF (Disabled)
#pragma config CP7 = OFF        // Code Protect 1C000-1FFFF (Disabled)

// CONFIG5H
#pragma config CPB = OFF        // Code Protect Boot (Disabled)
#pragma config CPD = OFF        // Data EE Read Protect (Disabled)

// CONFIG6L
#pragma config WRT0 = OFF       // Table Write Protect 00800-03FFF (Disabled)
#pragma config WRT1 = OFF       // Table Write Protect 04000-07FFF (Disabled)
#pragma config WRT2 = OFF       // Table Write Protect 08000-0BFFF (Disabled)
#pragma config WRT3 = OFF       // Table Write Protect 0C000-0FFFF (Disabled)
#pragma config WRT4 = OFF       // Table Write Protect 10000-13FFF (Disabled)
#pragma config WRT5 = OFF       // Table Write Protect 14000-17FFF (Disabled)
#pragma config WRT6 = OFF       // Table Write Protect 18000-1BFFF (Disabled)
#pragma config WRT7 = OFF       // Table Write Protect 1C000-1FFFF (Disabled)

// CONFIG6H
#pragma config WRTC = OFF       // Config. Write Protect (Disabled)
#pragma config WRTB = OFF       // Table Write Protect Boot (Disabled)
#pragma config WRTD = OFF       // Data EE Write Protect (Disabled)

// CONFIG7L
#pragma config EBRT0 = OFF      // Table Read Protect 00800-03FFF (Disabled)
#pragma config EBRT1 = OFF      // Table Read Protect 04000-07FFF (Disabled)
#pragma config EBRT2 = OFF      // Table Read Protect 08000-0BFFF (Disabled)
#pragma config EBRT3 = OFF      // Table Read Protect 0C000-0FFFF (Disabled)
#pragma config EBRT4 = OFF      // Table Read Protect 10000-13FFF (Disabled)
#pragma config EBRT5 = OFF      // Table Read Protect 14000-17FFF (Disabled)
#pragma config EBRT6 = OFF      // Table Read Protect 18000-1BFFF (Disabled)
#pragma config EBRT7 = OFF      // Table Read Protect 1C000-1FFFF (Disabled)

// CONFIG7H
#pragma config EBRTB = OFF      // Table Read Protect Boot (Disabled)

int i=0;
unsigned char veri[5];
void spi_hazirla()
{
    /*C0:1, C1:0, C2:1,C3:CLK ,C4:SDI,C5:SDO ,C6 C7 BOS*/
     TRISC=0b00010101;
     
     SSP1CON1bits.SSPM0 = 0;
     SSP1CON1bits.SSPM1 = 0;
     SSP1CON1bits.SSPM2 = 0;
     SSP1CON1bits.SSPM3 = 0;
     SSP1CON1bits.CKP = 0; // clock idle low
     SSP1CON1bits.SSPOV=0;
     SSP1CON1bits.WCOL=0;
     
     
     SSPBUF=0;
    
     SSP1STATbits.BF=0;
     SSP1STATbits.CKE = 1; 
     SSP1STATbits.SMP = 1; 
   
  
     SSP1CON1bits.SSPEN = 1; // Enable bit

}



void yaz(unsigned char veri)
{
  SSP1STATbits.BF=0;
  SSPBUF=veri;
  while(!SSP1STATbits.BF);

}

unsigned char veriAl()
{
  SSP1STATbits.BF=0;
  while(!SSP1STATbits.BF);
  
  return SSPBUF;
  
}

void uart_hazirla()
{


    
    TRISGbits.TRISG2=1;//Rx input
    TRISGbits.TRISG1=0;//Tx output
    
    
    /*BR=8MHZ/[16 (n + 1)]*/
    SPBRG2=51;
    SPBRGH2=0;
    
    
    
    BAUDCON2bits.BRG16=0;
    
    TXSTA2bits.TX9=0;//8 bit
    TXSTA2bits.BRGH=1;
    TXSTA2bits.TXEN=1;
    TXSTA2bits.SYNC=0;
    
    RCSTA2bits.SPEN=1;
   
    
  
   
   

}

void uart_veri_yolla(unsigned char *dizi)
{

    while(*dizi)
    {
    
    TXREG2=*dizi;
    while(!TXSTA2bits.TRMT);
    dizi++;
    }
    
   
}
void main(void) {
    
    //TRISA=0b00000000;
    //PORTA=0;
    
    
    OSCCONbits.IRCF0 = 0;
    OSCCONbits.IRCF1 = 1;
    OSCCONbits.IRCF2 = 1;
    
    
    OSCCONbits.IDLEN=0;
    OSCCONbits.SCS1=1;
    OSCCONbits.SCS0=0;
    
    while(OSCCONbits.HFIOFS !=1);
    uart_hazirla();
    
    while(1)
    {
        
        
        
        
        sprintf(veri,"%d\n",i);
        uart_veri_yolla(veri);
        i++;
        if(i==255)
            i=0;
   
       __delay_ms(1000);
        
        
        /*
        PORTA=0x20;
        __delay_ms(1000);
         PORTA=0x00;
        __delay_ms(1000);
        
    */
    }
    return;
}
